package com.example.mi_aplicacion.Navigation



sealed class Route(val path: String){
    data object Home     : Route("home")     // Ruta Home
    data object Login    : Route("login")    // Ruta Login
    data object Register : Route("register") // Ruta Registro

    data object post : Route("Publicar")

    data object PostDetail : Route("postDetail") {
        fun createRoute(temaId: Int) = "postDetail$temaId"
    }

    data object UserProfile : Route("perfil")

    data object AdminPanel : Route("Panel del administrador")

    data object Settings : Route("Ajustes")

    data object MoteratorPanel : Route("Panel del moderador")
}