package com.example.mi_aplicacion.ui.Screen

import androidx.compose.runtime.Composable

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(){

}