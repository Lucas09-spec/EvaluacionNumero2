package com.example.mi_aplicacion.Navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController


@Composable
fun NavGraph() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Route.Home.path) {

        // ------------------- Home -------------------
        composable(Route.Home.path) {
            HomeScreen(
                onTemaClick = { tema ->
                    navController.navigate(Route.PostDetail.createRoute(tema.id))
                },
                onCreateTemaClick = {
                    navController.navigate(Route.CreatePost.path)
                }
            )
        }

        // ------------------- Detalle de tema -------------------
        composable(
            Route.PostDetail.path,
            arguments = listOf(navArgument("temaId") { type = NavType.IntType })
        ) { backStackEntry ->
            val temaId = backStackEntry.arguments?.getInt("temaId") ?: 0
            PostDetailScreen(
                temaId = temaId,
                onBack = { navController.popBackStack() }
            )
        }

        // ------------------- Crear nuevo tema -------------------
        composable(Route.CreatePost.path) {
            CreatePostScreen(
                onBack = { navController.popBackStack() }
            )
        }

        // ------------------- Ajustes / Settings -------------------
        composable(Route.Settings.path) {
            SettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }

        // ------------------- Login -------------------
        composable(Route.Login.path) {
        }

        // ------------------- Register -------------------
        composable(Route.Register.path) {
        }

        // ------------------- Admin Panel -------------------
        composable(Route.AdminPanel.path) {
        }

        // ------------------- Moderator Panel -------------------
        composable(Route.ModeratorPanel.path) {
        }
    }
}