package com.example.mi_aplicacion.ui.Screen

import android.R
import android.content.res.Resources
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview


@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HomeScren(){
    Scaffold(
    ) {

        paddingValues ->  paddingValues
        Text(text ="Hola perro", modifier = Modifier.background(androidx.compose.ui.graphics.Color.Red))

    }

}


