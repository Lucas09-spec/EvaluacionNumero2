package com.example.mi_aplicacion.data.Repository;

public class UserRepository {
}
